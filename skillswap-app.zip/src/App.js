import React, { useState } from "react";

function App() {
  const [teachSkill, setTeachSkill] = useState("");
  const [learnSkill, setLearnSkill] = useState("");
  const [matches, setMatches] = useState([]);

  const handleMatch = () => {
    if (teachSkill && learnSkill) {
      setMatches([...matches, { teach: teachSkill, learn: learnSkill }]);
      setTeachSkill("");
      setLearnSkill("");
    }
  };

  return (
    <div style={{ maxWidth: "600px", margin: "0 auto" }}>
      <h1>SkillSwap</h1>
      <p>Swap Skills, Grow Together.</p>
      <div>
        <input
          type="text"
          placeholder="I can teach..."
          value={teachSkill}
          onChange={(e) => setTeachSkill(e.target.value)}
          style={{ width: "100%", padding: "10px", marginBottom: "10px" }}
        />
        <input
          type="text"
          placeholder="I want to learn..."
          value={learnSkill}
          onChange={(e) => setLearnSkill(e.target.value)}
          style={{ width: "100%", padding: "10px", marginBottom: "10px" }}
        />
        <button onClick={handleMatch} style={{ width: "100%", padding: "10px" }}>
          Find a Match
        </button>
      </div>
      <div style={{ marginTop: "20px" }}>
        <h2>Matches</h2>
        {matches.length === 0 ? (
          <p>No matches yet.</p>
        ) : (
          matches.map((match, index) => (
            <div key={index} style={{ border: "1px solid #ccc", padding: "10px", marginBottom: "10px" }}>
              <p><strong>Teach:</strong> {match.teach}</p>
              <p><strong>Learn:</strong> {match.learn}</p>
            </div>
          ))
        )}
      </div>
    </div>
  );
}

export default App;